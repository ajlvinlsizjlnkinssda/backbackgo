import { vlessJs } from './vless-js';

describe('vlessJs', () => {
  it('should work', () => {
    expect(vlessJs()).toEqual('vless-js');
  });
});
