type V2Option = {
  ws0Rtt: boolean;
};

export { V2Option };
