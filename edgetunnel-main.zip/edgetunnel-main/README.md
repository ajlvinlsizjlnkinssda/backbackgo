# Edge Tunnel（Beta）

Running **V2ray** in the edge/serverless runtime.

# Documentation

**!!If your find project can't use, please check the your deploy page and rescan the QRcode!!!!**

https://edgetunnel.github.io/edgetunnel/

# Feedback

If you have any questions, please open GitHub issue or use https://t.me/edgetunnel for communication.

> no emotional damage from the community.
